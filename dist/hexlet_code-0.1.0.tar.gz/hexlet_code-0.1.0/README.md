### Hexlet tests and linter status:
[![Actions Status](https://github.com/Bemax16/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Bemax16/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/edb5370f8b9891a98bdb/maintainability)](https://codeclimate.com/github/Bemax16/python-project-49/maintainability)
